<h1 align="center">Welcome to Ducko's V14 (Full Bot)</h1>
<h3 align="center">Bot made with 💖 by Ducko#7068</h3>

<div align="center">
 
[![discord](https://img.shields.io/discord/909261119103832084?style=for-the-badge&color=5865f2&label=Discord)](https://discord.gg/TKz7BMwEap)

[![issues](https://img.shields.io/github/issues/DuckoDas/DJS-Suggestion-System-v14?style=for-the-badge&color=d84559)](https://github.com/DuckoDas/DJS-Suggestion-System-v14)
[![stars](https://img.shields.io/github/stars/DuckoDas/DJS-Suggestion-System-v14?color=009F81&label=stars&style=for-the-badge)](https://github.com/DuckoDas/DJS-Suggestion-System-v14)
[![followers](https://img.shields.io/github/followers/DuckoDas?color=009F81&style=for-the-badge)](https://github.com/DuckoDas/)

**Advanced Suggestions System with Modals and Buttons**

**Upvote and Downvote button**

**Role to accept or decline or restart a suggestion!**

**Full Ticket System Included**

</div>
<hr>

## Features
- Custom colors for default the embed, accepted suggestions, and declined suggestions (Setup)
- Accept or decline or just start the suggestion again (Commands)
- Upvote or downvote a suggestion
- Add and remove people from tickets
- Create tickets and close or archive them!

## **Dependencies:**
- NodeJS
- [MongoDB Database (FREE)](https://www.mongodb.com/)

## **Contributors**

<a href="https://github.com/duckodas/fulldiscordbot/graphs/contributors">
  <img src="https://stg.contrib.rocks/image?repo=duckodas/fulldiscordbot" />
</a>
